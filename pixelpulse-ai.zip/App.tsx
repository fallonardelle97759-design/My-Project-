
import React, { useState, useEffect, useMemo } from 'react';
import { 
  AIImage, 
  GenerationSettings, 
  STYLE_PRESETS, 
  ASPECT_RATIOS, 
  AspectRatio,
  PromptHistoryItem
} from './types';
import { generateSingleImage } from './services/geminiService';
import ImageCard from './components/ImageCard';
import { WandIcon, TrashIcon, XIcon, MoonIcon, SunIcon, HistoryIcon, DownloadIcon, CheckIcon } from './components/Icons';

const SplashScreen: React.FC<{ onFinish: () => void }> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 animate-in fade-in duration-700">
      <div className="relative mb-8 animate-in zoom-in-50 slide-in-from-bottom-10 duration-1000">
        <div className="absolute inset-0 bg-white/20 blur-3xl rounded-full scale-150 animate-pulse-slow"></div>
        <div className="relative p-8 bg-white/10 backdrop-blur-xl border border-white/20 rounded-[2.5rem] shadow-2xl">
          <div className="scale-[3] text-white">
            <WandIcon />
          </div>
        </div>
      </div>
      
      <div className="text-center animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300">
        <h1 className="text-5xl font-black text-white tracking-tighter mb-3">
          PixelPulse AI
        </h1>
        <p className="text-indigo-100 text-lg font-medium opacity-80">
          Create images from text
        </p>
      </div>

      <div className="absolute bottom-16 flex flex-col items-center space-y-4 animate-in fade-in duration-1000 delay-700">
        <div className="flex space-x-1.5">
          <div className="w-1.5 h-1.5 bg-white/30 rounded-full animate-bounce"></div>
          <div className="w-1.5 h-1.5 bg-white/30 rounded-full animate-bounce delay-75"></div>
          <div className="w-1.5 h-1.5 bg-white/30 rounded-full animate-bounce delay-150"></div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  // Splash state
  const [showSplash, setShowSplash] = useState(true);
  
  // PWA Installation State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  // State
  const [prompt, setPrompt] = useState('');
  const [settings, setSettings] = useState<GenerationSettings>({
    aspectRatio: '1:1',
    style: 'none',
    batchSize: 4
  });
  const [gallery, setGallery] = useState<AIImage[]>([]);
  const [promptHistory, setPromptHistory] = useState<PromptHistoryItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState<boolean[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'gallery'>('home');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [filter, setFilter] = useState<'all' | 'favorites'>('all');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [showHistoryInGallery, setShowHistoryInGallery] = useState(false);

  // Persistence & Theme & PWA listeners
  useEffect(() => {
    const savedGallery = localStorage.getItem('pixelpulse_gallery');
    const savedHistory = localStorage.getItem('pixelpulse_history');
    const savedTheme = localStorage.getItem('pixelpulse_theme');

    if (savedGallery) setGallery(JSON.parse(savedGallery));
    if (savedHistory) setPromptHistory(JSON.parse(savedHistory));
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }

    // Capture PWA install event
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    });

    window.addEventListener('appinstalled', () => {
      setIsInstallable(false);
      setDeferredPrompt(null);
    });
  }, []);

  useEffect(() => {
    localStorage.setItem('pixelpulse_gallery', JSON.stringify(gallery));
  }, [gallery]);

  useEffect(() => {
    localStorage.setItem('pixelpulse_history', JSON.stringify(promptHistory));
  }, [promptHistory]);

  const toggleTheme = () => {
    setIsDarkMode(prev => {
      const next = !prev;
      localStorage.setItem('pixelpulse_theme', next ? 'dark' : 'light');
      if (next) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstallable(false);
    }
    setDeferredPrompt(null);
  };

  // Handlers
  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setError(null);
    setGenerationProgress(new Array(settings.batchSize).fill(false));

    const stylePrompt = STYLE_PRESETS.find(s => s.id === settings.style)?.prompt || '';
    
    try {
      const generateWithProgress = async (index: number) => {
        try {
          const url = await generateSingleImage(prompt, settings.aspectRatio, stylePrompt);
          setGenerationProgress(prev => {
            const next = [...prev];
            next[index] = true;
            return next;
          });
          return url;
        } catch (e) {
          console.error(`Error generating image ${index + 1}:`, e);
          throw e;
        }
      };

      const imageUrls = await Promise.all(
        Array(settings.batchSize).fill(null).map((_, i) => generateWithProgress(i))
      );
      
      const newImages: AIImage[] = imageUrls.map(url => ({
        id: crypto.randomUUID(),
        url,
        prompt: prompt,
        timestamp: Date.now(),
        aspectRatio: settings.aspectRatio,
        isFavorite: false,
        style: settings.style
      }));

      // Add to prompt history if unique
      if (!promptHistory.some(h => h.text.toLowerCase() === prompt.toLowerCase())) {
        setPromptHistory(prev => [{ id: crypto.randomUUID(), text: prompt, timestamp: Date.now() }, ...prev].slice(0, 50));
      }

      setGallery(prev => [...newImages, ...prev]);
      setActiveTab('gallery');
    } catch (err: any) {
      setError(err.message || "Failed to generate images. The AI might be busy. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const deleteImage = (id: string) => {
    setGallery(prev => prev.filter(img => img.id !== id));
    if (selectedIds.has(id)) {
      const next = new Set(selectedIds);
      next.delete(id);
      setSelectedIds(next);
    }
  };

  const toggleFavorite = (id: string) => {
    setGallery(prev => prev.map(img => 
      img.id === id ? { ...img, isFavorite: !img.isFavorite } : img
    ));
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const batchDownload = () => {
    const ids = isSelectionMode ? Array.from(selectedIds) : filteredGallery.map(img => img.id);
    if (ids.length === 0) return;
    
    ids.forEach((id, index) => {
      const img = gallery.find(g => g.id === id);
      if (img) {
        setTimeout(() => {
          const link = document.createElement('a');
          link.href = img.url;
          link.download = `pixelpulse-batch-${img.id}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }, index * 300); // Stagger to avoid browser request limits
      }
    });
  };

  const deleteSelected = () => {
    if (window.confirm(`Are you sure you want to delete these ${selectedIds.size} images?`)) {
      setGallery(prev => prev.filter(img => !selectedIds.has(img.id)));
      setSelectedIds(new Set());
      setIsSelectionMode(false);
    }
  };

  const filteredGallery = useMemo(() => 
    gallery.filter(img => filter === 'all' ? true : img.isFavorite),
    [gallery, filter]
  );

  const charCount = prompt.length;
  const maxChars = 500;

  return (
    <>
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
      
      <div className={`min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300 ${showSplash ? 'hidden' : 'block'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          
          {/* Navigation & Theme Header */}
          <header className="flex flex-col md:flex-row items-center justify-between mb-12 space-y-6 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-200 dark:shadow-indigo-900/30">
                <WandIcon />
              </div>
              <div>
                <h1 className="text-3xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600 dark:from-indigo-400 dark:to-violet-400 tracking-tight">
                  PixelPulse AI
                </h1>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Professional AI Generator</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 bg-white/50 dark:bg-slate-800/50 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 backdrop-blur-sm">
              <button 
                onClick={() => setActiveTab('home')}
                className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'home' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-md' : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'}`}
              >
                <span>Generator</span>
              </button>
              <button 
                onClick={() => setActiveTab('gallery')}
                className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'gallery' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-md' : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'}`}
              >
                <span>Gallery</span>
                {gallery.length > 0 && <span className="ml-1 px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px]">{gallery.length}</span>}
              </button>
              
              <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1" />
              
              <div className="flex items-center">
                {isInstallable && (
                  <button 
                    onClick={handleInstallApp}
                    className="mr-2 p-2.5 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 hover:bg-green-200 dark:hover:bg-green-800/50 rounded-xl transition-all animate-bounce"
                    title="Install as Android App"
                  >
                    <DownloadIcon />
                  </button>
                )}
                <button 
                  onClick={toggleTheme}
                  className="p-2.5 hover:bg-white dark:hover:bg-slate-700 rounded-xl text-slate-500 dark:text-slate-400 transition-all"
                  title="Toggle Theme"
                >
                  {isDarkMode ? <SunIcon /> : <MoonIcon />}
                </button>
              </div>
            </div>
          </header>

          <main className="animate-in fade-in slide-in-from-bottom-2 duration-500">
            {activeTab === 'home' ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Creator Panel */}
                <div className="lg:col-span-8 space-y-6">
                  <div className="bg-white dark:bg-slate-800 p-6 sm:p-10 rounded-3xl shadow-2xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-700 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-violet-500" />
                    
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Create New Visuals</h2>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${charCount > maxChars ? 'bg-red-100 text-red-600' : 'bg-slate-100 dark:bg-slate-900 text-slate-400'}`}>
                        {charCount}/{maxChars}
                      </span>
                    </div>
                    
                    <div className="relative">
                      <textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value.slice(0, maxChars))}
                        placeholder="Describe what you want to see... e.g. A futuristic workspace with glowing neon plants"
                        className="w-full h-48 p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border-2 border-transparent focus:border-indigo-500 dark:focus:border-indigo-400 focus:bg-white dark:focus:bg-slate-900 outline-none transition-all text-lg text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600 resize-none leading-relaxed shadow-inner"
                      />
                    </div>

                    <div className="mt-8 flex flex-col sm:flex-row gap-4">
                      <button 
                        disabled={isGenerating || !prompt.trim()}
                        onClick={handleGenerate}
                        className="flex-[2] bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 disabled:bg-slate-200 dark:disabled:bg-slate-800 disabled:text-slate-400 text-white font-extrabold py-5 px-8 rounded-2xl shadow-xl shadow-indigo-200 dark:shadow-none transition-all flex items-center justify-center space-x-3 active:scale-[0.98]"
                      >
                        {isGenerating ? (
                          <div className="flex items-center space-x-3">
                            <svg className="animate-spin h-6 w-6 text-white" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>Generating Batch...</span>
                          </div>
                        ) : (
                          <>
                            <WandIcon />
                            <span>Generate {settings.batchSize} Variation{settings.batchSize > 1 ? 's' : ''}</span>
                          </>
                        )}
                      </button>
                      {promptHistory.length > 0 && (
                        <button 
                          onClick={() => setPrompt(promptHistory[0].text)}
                          className="flex-1 bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-indigo-200 dark:hover:border-indigo-900 hover:text-indigo-600 dark:hover:text-indigo-400 font-bold rounded-2xl transition-all flex items-center justify-center space-x-2"
                          title="Load last used prompt"
                        >
                          <HistoryIcon />
                          <span>Last Prompt</span>
                        </button>
                      )}
                    </div>

                    {error && (
                      <div className="mt-6 p-5 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-2xl flex items-center space-x-3 text-red-600 dark:text-red-400 animate-in fade-in zoom-in duration-300">
                        <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full"><XIcon /></div>
                        <p className="text-sm font-semibold">{error}</p>
                      </div>
                    )}
                  </div>

                  {/* Inspiration Section */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-slate-100/50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-700">
                      <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-4">Popular Styles</h3>
                      <div className="flex flex-wrap gap-2">
                        {STYLE_PRESETS.filter(s => s.id !== 'none').map(s => (
                          <button 
                            key={s.id}
                            onClick={() => setSettings(prev => ({ ...prev, style: s.id }))}
                            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border-2 ${settings.style === s.id ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-indigo-300 dark:hover:border-indigo-800'}`}
                          >
                            {s.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="p-6 bg-slate-100/50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-700">
                      <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-4">Quick Tips</h3>
                      <ul className="text-xs text-slate-500 dark:text-slate-400 space-y-2.5 font-medium">
                        <li className="flex items-center space-x-2"><span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /><span>Add "high quality", "8k", or "studio lighting" for crisp details.</span></li>
                        <li className="flex items-center space-x-2"><span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /><span>Try mentioning specific lenses like "35mm" or "macro".</span></li>
                        <li className="flex items-center space-x-2"><span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" /><span>Keep it concise but vivid for better AI understanding.</span></li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Configuration Sidebar */}
                <div className="lg:col-span-4 space-y-6">
                  <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-700 sticky top-8">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-8 flex items-center">
                      <svg className="w-5 h-5 mr-3 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
                      Settings
                    </h2>
                    
                    <div className="space-y-10">
                      {/* Ratio Section */}
                      <div>
                        <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-4">Aspect Ratio</label>
                        <div className="grid grid-cols-2 gap-3">
                          {ASPECT_RATIOS.map((ar) => (
                            <button 
                              key={ar.id}
                              onClick={() => setSettings(s => ({ ...s, aspectRatio: ar.id }))}
                              className={`flex items-center space-x-3 px-4 py-3.5 rounded-2xl border-2 transition-all group ${settings.aspectRatio === ar.id ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 shadow-md' : 'border-slate-100 dark:border-slate-700 hover:border-slate-200 dark:hover:border-slate-600 text-slate-500 dark:text-slate-400'}`}
                            >
                              <span className="text-xl">{ar.icon}</span>
                              <span className="text-sm font-bold">{ar.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Quantity Section */}
                      <div>
                        <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-4">Batch Size</label>
                        <div className="flex bg-slate-50 dark:bg-slate-900 rounded-2xl p-1.5 border border-slate-100 dark:border-slate-700">
                          {[1, 2, 3, 4].map(num => (
                            <button 
                              key={num}
                              onClick={() => setSettings(s => ({ ...s, batchSize: num }))}
                              className={`flex-1 py-3 text-sm font-black rounded-xl transition-all ${settings.batchSize === num ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-lg' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'}`}
                            >
                              {num}
                            </button>
                          ))}
                        </div>
                        <p className="mt-3 text-[10px] text-slate-400 font-medium text-center">Batch generation is faster but uses more API capacity.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Gallery View with Enhanced Controls */
              <div className="space-y-10">
                <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-6">
                  <div>
                    <h2 className="text-4xl font-black text-slate-800 dark:text-white tracking-tight">Your Gallery</h2>
                    <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">Manage, filter, and export your high-resolution generations.</p>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-4 bg-white/50 dark:bg-slate-800/50 p-3 rounded-3xl border border-slate-200 dark:border-slate-700 backdrop-blur-md">
                    {/* History Toggle Button */}
                    <button 
                      onClick={() => setShowHistoryInGallery(!showHistoryInGallery)}
                      className={`flex items-center space-x-2 px-5 py-3 rounded-2xl text-xs font-bold border-2 transition-all ${showHistoryInGallery ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'}`}
                    >
                      <HistoryIcon />
                      <span>Prompt History</span>
                    </button>

                    <div className="h-8 w-px bg-slate-200 dark:bg-slate-700 hidden sm:block" />

                    {/* Favorites Filter */}
                    <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
                      <button 
                        onClick={() => setFilter('all')}
                        className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${filter === 'all' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-md' : 'text-slate-500'}`}
                      >
                        All
                      </button>
                      <button 
                        onClick={() => setFilter('favorites')}
                        className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${filter === 'favorites' ? 'bg-white dark:bg-slate-700 text-red-500 shadow-md' : 'text-slate-500'}`}
                      >
                        Starred
                      </button>
                    </div>

                    <div className="h-8 w-px bg-slate-200 dark:bg-slate-700 hidden sm:block" />

                    {/* Multi-Select Toggle */}
                    <button 
                      onClick={() => {
                        setIsSelectionMode(!isSelectionMode);
                        setSelectedIds(new Set());
                      }}
                      className={`px-5 py-2.5 text-xs font-bold rounded-xl transition-all border-2 ${isSelectionMode ? 'bg-amber-500 border-amber-500 text-white' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-amber-400'}`}
                    >
                      {isSelectionMode ? 'Cancel' : 'Multi-Select'}
                    </button>

                    {/* Batch Actions Container */}
                    {(isSelectionMode && selectedIds.size > 0) || (!isSelectionMode && filteredGallery.length > 0) ? (
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={batchDownload}
                          className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 dark:bg-indigo-500 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 dark:shadow-none transition-all"
                        >
                          <DownloadIcon />
                          <span>{isSelectionMode ? `Download (${selectedIds.size})` : 'Download All'}</span>
                        </button>
                        
                        {isSelectionMode && (
                          <button 
                            onClick={deleteSelected}
                            className="p-3 bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 rounded-xl hover:bg-red-100 transition-colors"
                            title="Delete Selected"
                          >
                            <TrashIcon />
                          </button>
                        )}
                      </div>
                    ) : null}
                  </div>
                </div>

                {/* Inline Prompt History Panel (Toggleable) */}
                {showHistoryInGallery && (
                  <div className="p-8 bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-3xl animate-in slide-in-from-top duration-300">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-sm font-black text-indigo-900 dark:text-indigo-300 uppercase tracking-widest">Recent Prompt History</h3>
                      <button onClick={() => setShowHistoryInGallery(false)} className="text-indigo-400 hover:text-indigo-600 transition-colors"><XIcon /></button>
                    </div>
                    {promptHistory.length === 0 ? (
                      <p className="text-slate-400 text-sm italic">No history yet. Start generating!</p>
                    ) : (
                      <div className="flex flex-wrap gap-3">
                        {promptHistory.map(h => (
                          <button 
                            key={h.id}
                            onClick={() => { setPrompt(h.text); setActiveTab('home'); }}
                            className="group relative px-5 py-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-medium hover:border-indigo-400 dark:hover:border-indigo-700 hover:shadow-md transition-all truncate max-w-xs text-left"
                          >
                            {h.text}
                            <div className="absolute top-0 right-0 p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <WandIcon />
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {filteredGallery.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-32 text-center space-y-6 bg-white dark:bg-slate-800/30 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-700">
                    <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-slate-300 dark:text-slate-600 animate-pulse-slow">
                       <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    </div>
                    <div>
                      <h3 className="text-2xl font-black text-slate-800 dark:text-slate-200">
                        {filter === 'favorites' ? 'No starred items yet' : 'Gallery Empty'}
                      </h3>
                      <p className="text-slate-400 dark:text-slate-500 max-w-xs mx-auto font-medium">
                        {filter === 'favorites' ? 'Star images in the gallery to quickly access your top picks.' : 'Ready to bring your ideas to life? Return to the generator to start.'}
                      </p>
                    </div>
                    <button 
                      onClick={() => setActiveTab('home')}
                      className="px-10 py-4 bg-indigo-600 dark:bg-indigo-500 text-white font-black rounded-2xl shadow-xl shadow-indigo-200 dark:shadow-none transition-all active:scale-95"
                    >
                      Start Generating
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                    {filteredGallery.map(image => (
                      <ImageCard 
                        key={image.id} 
                        image={image} 
                        onDelete={deleteImage} 
                        onToggleFavorite={toggleFavorite}
                        isSelected={selectedIds.has(image.id)}
                        onToggleSelect={toggleSelect}
                        isSelectionMode={isSelectionMode}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </main>

          {/* Improved Loading Overlay with Individual Progress Indicators */}
          {isGenerating && (
            <div className="fixed inset-0 bg-white/95 dark:bg-slate-900/98 backdrop-blur-xl z-[100] flex items-center justify-center flex-col p-8 text-center animate-in fade-in duration-300">
              <div className="relative mb-12">
                <div className="w-40 h-40 border-[6px] border-indigo-100 dark:border-slate-800 border-t-indigo-600 dark:border-t-indigo-400 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center text-indigo-600 dark:text-indigo-400 scale-[2]">
                  <WandIcon />
                </div>
              </div>
              
              <div className="mb-10 max-w-lg">
                <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-3">Crafting Your Visuals</h2>
                <p className="text-slate-500 dark:text-slate-400 font-medium">The AI is iterating on "{prompt.length > 50 ? prompt.substring(0, 50) + '...' : prompt}"</p>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 w-full max-w-2xl mb-12">
                {generationProgress.map((isDone, idx) => (
                  <div key={idx} className={`relative p-6 rounded-3xl border-2 transition-all duration-500 overflow-hidden ${isDone ? 'border-green-500 bg-green-50 dark:bg-green-900/10 shadow-lg shadow-green-100 dark:shadow-none' : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800/40'}`}>
                    {isDone && <div className="absolute top-0 left-0 w-full h-1 bg-green-500" />}
                    <div className="flex flex-col items-center space-y-4">
                      {isDone ? (
                        <div className="text-green-500 animate-in zoom-in duration-500">
                          <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
                        </div>
                      ) : (
                        <div className="w-10 h-10 border-[4px] border-indigo-600/10 border-t-indigo-600 rounded-full animate-spin"></div>
                      )}
                      <span className={`text-[11px] font-black uppercase tracking-widest ${isDone ? 'text-green-600 dark:text-green-400' : 'text-slate-400 dark:text-slate-600'}`}>
                        {isDone ? 'Ready' : `Image ${idx + 1}`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col items-center space-y-4">
                 <div className="h-1.5 w-64 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                   <div className="h-full bg-indigo-600 dark:bg-indigo-400 transition-all duration-1000 ease-in-out" style={{ width: `${(generationProgress.filter(p => p).length / settings.batchSize) * 100}%` }}></div>
                 </div>
                 <p className="text-[10px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-[0.2em]">Batch Rendering in Progress</p>
              </div>
            </div>
          )}

          {/* Global Footer */}
          <footer className="mt-24 pt-10 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-slate-400 dark:text-slate-500 text-xs font-bold uppercase tracking-widest">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <p>&copy; {new Date().getFullYear()} PixelPulse AI Engine</p>
            </div>
            <div className="flex space-x-8 mt-6 sm:mt-0">
              <a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Privacy</a>
              <a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Safety</a>
              <a href="#" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">API Docs</a>
            </div>
          </footer>
        </div>
      </div>
    </>
  );
};

export default App;
