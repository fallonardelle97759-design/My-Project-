
export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9";

export interface AIImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
  aspectRatio: AspectRatio;
  isFavorite: boolean;
  style?: string;
}

export interface PromptHistoryItem {
  id: string;
  text: string;
  timestamp: number;
}

export interface GenerationSettings {
  aspectRatio: AspectRatio;
  style: string;
  batchSize: number;
}

export const STYLE_PRESETS = [
  { id: 'none', label: 'Default', prompt: '' },
  { id: 'realistic', label: 'Realistic', prompt: 'photorealistic, highly detailed, 8k resolution, professional lighting' },
  { id: 'minimalist', label: 'Minimalist', prompt: 'minimalist style, clean lines, simple background, product photography' },
  { id: 'cartoon', label: 'Cartoon', prompt: 'vibrant cartoon illustration, 2d, high quality' },
  { id: '3d-render', label: '3D Render', prompt: 'octane render, unreal engine 5, 3d digital art, cinematic' },
  { id: 'sketch', label: 'Hand Drawn', prompt: 'detailed pencil sketch, artistic, hand-drawn texture' }
];

export const ASPECT_RATIOS: { id: AspectRatio; label: string; icon: string }[] = [
  { id: '1:1', label: 'Square', icon: '□' },
  { id: '4:3', label: 'Standard', icon: '▭' },
  { id: '16:9', label: 'Wide', icon: '▬' },
  { id: '9:16', label: 'Portrait', icon: '▯' }
];
