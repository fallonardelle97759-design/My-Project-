
import { GoogleGenAI } from "@google/genai";
import { AspectRatio } from "../types";

/**
 * Generates an image using the Gemini 2.5 Flash Image model.
 * Returns a base64 data URL string.
 */
export async function generateSingleImage(
  prompt: string, 
  aspectRatio: AspectRatio,
  stylePrompt: string = ""
): Promise<string> {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing. Please ensure process.env.API_KEY is configured.");
  }

  const ai = new GoogleGenAI({ apiKey });
  const finalPrompt = stylePrompt ? `${prompt}, ${stylePrompt}` : prompt;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: finalPrompt },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
        },
      },
    });

    const candidate = response.candidates?.[0];
    if (!candidate) throw new Error("No candidates returned from AI.");

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("No image data found in response parts.");
  } catch (error: any) {
    console.error("Gemini Image Generation Error:", error);
    throw error;
  }
}
