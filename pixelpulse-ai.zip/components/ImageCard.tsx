
import React from 'react';
import { AIImage } from '../types';
import { DownloadIcon, TrashIcon, HeartIcon, CheckIcon } from './Icons';

interface ImageCardProps {
  image: AIImage;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  isSelected?: boolean;
  onToggleSelect?: (id: string) => void;
  isSelectionMode?: boolean;
}

const ImageCard: React.FC<ImageCardProps> = ({ 
  image, 
  onDelete, 
  onToggleFavorite, 
  isSelected, 
  onToggleSelect, 
  isSelectionMode 
}) => {
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `pixelpulse-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleClick = () => {
    if (isSelectionMode && onToggleSelect) {
      onToggleSelect(image.id);
    }
  };

  return (
    <div 
      onClick={handleClick}
      className={`group relative bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border ${isSelected ? 'border-indigo-600 ring-2 ring-indigo-600/20' : 'border-slate-100 dark:border-slate-700'}`}
    >
      <div className="aspect-square bg-slate-100 dark:bg-slate-900 overflow-hidden relative">
        <img 
          src={image.url} 
          alt={image.prompt} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        
        {isSelectionMode && (
          <div className={`absolute top-3 left-3 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${isSelected ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white/50 border-white text-transparent'}`}>
            <CheckIcon />
          </div>
        )}
      </div>
      
      {/* Overlay Actions (Hide if selection mode is on to avoid accidental triggers) */}
      {!isSelectionMode && (
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-4">
          <div className="flex justify-end space-x-2">
            <button 
              onClick={(e) => { e.stopPropagation(); onToggleFavorite(image.id); }}
              className="p-2 bg-white/20 hover:bg-white/40 backdrop-blur-md rounded-full text-white transition-colors"
              title="Favorite"
            >
              <HeartIcon filled={image.isFavorite} />
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); onDelete(image.id); }}
              className="p-2 bg-white/20 hover:bg-red-500/80 backdrop-blur-md rounded-full text-white transition-colors"
              title="Delete"
            >
              <TrashIcon />
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <p className="text-white text-xs font-medium truncate pr-4 drop-shadow-md">
              {image.prompt}
            </p>
            <button 
              onClick={handleDownload}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition-all shadow-lg flex-shrink-0"
              title="Download"
            >
              <DownloadIcon />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageCard;
